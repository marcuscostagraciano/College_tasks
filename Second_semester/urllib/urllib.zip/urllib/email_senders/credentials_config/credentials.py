account_settings = {
  "sending_account": "",
  "password": "",
  "receiver_account": ""
}